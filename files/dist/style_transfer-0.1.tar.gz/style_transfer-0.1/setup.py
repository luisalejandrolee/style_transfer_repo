from setuptools import setup

setup(
    name='style_transfer',
    version='0.1',
    scripts=['predictor.py'])